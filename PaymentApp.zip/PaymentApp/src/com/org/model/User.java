package com.org.model;

import java.sql.Timestamp;

public class User {
	private Integer userId;
	private String userName;
	private String password;
	private Long mobileNo;
	private String emailId;
	private Timestamp loginTime;
	private Timestamp logoutTime;

	public User(){
		
	}
	
	public User(int userId){
		this.userId = userId;
	}
	
	public User(Long mobileNo){
		this.mobileNo = mobileNo;
	}
	
	public User(Long mobNo, String pwd){
		this.mobileNo = mobNo;
		this.password = pwd;
	}
	
	public User(String uName, String pwd, long mobNo, String emlId){
		this.userName = uName;
		this.password = pwd;
		this.mobileNo = mobNo;
		this.emailId = emlId;
	}
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public Timestamp getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Timestamp loginTime) {
		this.loginTime = loginTime;
	}

	public Timestamp getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(Timestamp logoutTime) {
		this.logoutTime = logoutTime;
	}
	
}
