package com.org.model;

import java.sql.Timestamp;

public class Transaction {
	
	private Integer transactionId;
	private Double amountSent;
	private Timestamp transactionDate;
	private User user;
	private Status status;
	
	public Transaction(){
		
	}
	
	public Transaction(Double amountSent, User user){
		this.amountSent = amountSent;
		this.user = user;
	}
	
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public Double getAmountSent() {
		return amountSent;
	}
	public void setAmountSent(Double amountSent) {
		this.amountSent = amountSent;
	}
	public Timestamp getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Timestamp transactionDate) {
		this.transactionDate = transactionDate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
}
