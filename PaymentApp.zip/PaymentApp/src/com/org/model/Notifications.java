package com.org.model;

import java.sql.Timestamp;

public class Notifications {
	
	private int notificationId;
	private String notification;
	private User user;
	private Timestamp date;
	
	public Notifications() {
		// TODO Auto-generated constructor stub
	}
	
	public Notifications(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}
	
	public String getNotification() {
		return notification;
	}
	public void setNotification(String notification) {
		this.notification = notification;
	}
		
}
