package com.org.businessService;

import com.org.model.User;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterService {
	
	String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
	
	//String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,20)";
	
	public boolean authenticateUserDetails(User user){
	    boolean flag = true;
	    
	    if(user.getPassword().length()<=6||user.getPassword().length()>=20){
	    	flag = false;
	    }else if(String.valueOf(user.getMobileNo()).length()!=10){
	    	flag = false;
	    }else if(!(user.getEmailId().matches(EMAIL_REGEX))){
	    	flag = false;
	    }else if(user.getUserName().length()==0){
	    	flag = false;
	    }
	    
	    return flag;
	}

}
