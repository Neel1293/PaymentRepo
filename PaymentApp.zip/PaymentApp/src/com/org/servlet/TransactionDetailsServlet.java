package com.org.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.dao.UserTransactionDetailsDao;
import com.org.model.Notifications;
import com.org.model.Transaction;
import com.org.model.User;


@WebServlet("/TransactionDetails.do")
public class TransactionDetailsServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		
		User modelUser = new User(user.getUserId());
		
		UserTransactionDetailsDao detailsDao = new UserTransactionDetailsDao();
		
		ArrayList<Transaction> transactionsDetails = detailsDao.getAllUserTransactionsDetails(modelUser);
		ArrayList<Transaction> receiveTransactionDetails = detailsDao.getAllUserReceiveTransactionsDetails(modelUser);
		
		//Notifications notify = new Notifications();
		//detailsDao.insertNotificationDetails(transactionsDetails,user);
		
		request.setAttribute("transactionDetails", transactionsDetails);
		request.setAttribute("receiveTransactionDetails", receiveTransactionDetails);
		
		RequestDispatcher disp = request.getRequestDispatcher("UserTransactions.jsp");
		disp.forward(request, response);	
		
	}

}
