package com.org.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.dao.UserDetailsDao;
import com.org.dao.UserTransactionDetailsDao;
import com.org.dao.LoginDao;
import com.org.model.Notifications;
import com.org.model.User;


@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long mobNo = Long.parseLong(request.getParameter("mobNo"));
		String pwd = request.getParameter("pwd");
		
		String msg = "";
		String forwardPage = "";
		
		User user = new User(mobNo,pwd);
		
		LoginDao lDao = new LoginDao();
		
		UserDetailsDao userDtlDao = new UserDetailsDao();
		UserTransactionDetailsDao detailsDao = new UserTransactionDetailsDao();
		
		
		/*
		for(int i=0;i<alNotify.size();i++){
			Notifications notification = alNotify.get(i);
			System.out.println(notification.getNotification());
		}*/
		
		if(lDao.checkUser(user)){
			if(userDtlDao.enterLoginTime(user)){
				
				User sessionUser = userDtlDao.getAllUserDetails(user);
				//Notification notification
				ArrayList<Notifications> alNotify = detailsDao.getAllUserNotifications(sessionUser);
				//System.out.println(alNotify);
				//System.out.println(alNotify.size());
				request.setAttribute("alNotify", alNotify);
				msg = msg + "Login Successfully";
				HttpSession sess = request.getSession();
				sess.setAttribute("user", sessionUser);
				forwardPage = "Home.jsp";
			}
		}else{
			msg = msg + "User doesn't exist";
			forwardPage = "Login.jsp";
		}
		
		
		request.setAttribute("message", msg);
		RequestDispatcher disp = request.getRequestDispatcher(forwardPage);
		disp.forward(request, response);
	}

}
