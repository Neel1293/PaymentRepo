package com.org.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.businessService.RegisterService;
import com.org.dao.EditUserDetailsDao;
import com.org.model.User;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/edit.do")
public class EditServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uName = request.getParameter("uName");
		String pwd = request.getParameter("pwd");
		Long mobNo = Long.parseLong(request.getParameter("mobNo"));
		String emlId = request.getParameter("emlId");
		
		System.out.println("Edited User Dtls : "+uName+"--"+pwd+"--"+mobNo+"--"+emlId);
		
		String msg = "";
		
		HttpSession sess = request.getSession();
		User user = (User)sess.getAttribute("user");
		
		RegisterService rs = new RegisterService();
		
		System.out.println("Session/Old Dtls are : "+user.getUserName()+"--"+user.getPassword()+"--"+user.getMobileNo()+"--"+user.getEmailId());
		
		if((user.getUserName().equals(uName))&&(user.getPassword().equals(pwd))&&(user.getMobileNo().equals(mobNo))&&(user.getEmailId().equals(emlId))){
			msg = msg + "Please provide some change!!";
		}else{
			User editedUser = new User(uName, pwd, mobNo, emlId);
			
			if(rs.authenticateUserDetails(editedUser)){
				user.setUserName(editedUser.getUserName());
				user.setPassword(editedUser.getPassword());
				user.setEmailId(editedUser.getEmailId());
				user.setMobileNo(editedUser.getMobileNo());
			
				System.out.println("Updated Session Dtls : "+user.getUserName()+"--"+user.getEmailId()+"--"+user.getPassword()+"--"+user.getMobileNo());
			
				EditUserDetailsDao eud = new EditUserDetailsDao();
			
				if(eud.editUserDetails(editedUser,user.getUserId())){
					msg = "User Edited Successfully";			
				}
			}else{
				msg = "Please provide right Details !!";
			}
		}
		
		request.setAttribute("msg", msg);
		
		RequestDispatcher rDisp = request.getRequestDispatcher("Profile.jsp");
		
		rDisp.forward(request, response);
	}

}
