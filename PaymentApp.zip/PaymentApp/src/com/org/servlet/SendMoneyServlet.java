package com.org.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.dao.UserDetailsDao;
import com.org.dao.UserTransactionDetailsDao;
import com.org.dao.MakeTransactionDao;
import com.org.model.Notifications;
import com.org.model.Transaction;
import com.org.model.User;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@WebServlet("/SendMoney.do")
public class SendMoneyServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long mobileNo = Long.parseLong(request.getParameter("mobNo"));
		Double amount = Double.parseDouble(request.getParameter("amt"));
		
		String msg = "";
		String nextPage = "";
		
		DecimalFormat df = new DecimalFormat("0.00");
		df.setMaximumFractionDigits(2);
		amount = Double.parseDouble(df.format(amount));		
		System.out.println(amount);
		
		 DateFormat datef = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
	     Date dateobj = new Date();
	     System.out.println(datef.format(dateobj));
	     //Timestamp timestamp = Timestamp.valueOf(datef.format(dateobj));
	    // System.out.println(timestamp);
	     //Need to change session variable to object type User
	     //Getting Sender user Id
	     HttpSession sess = request.getSession();
	     User user = (User)sess.getAttribute("user");
	     System.out.println(user.getMobileNo());
	     
	     User recUser = new User(mobileNo);
	     
	     UserDetailsDao getUserDetailsDao = new UserDetailsDao();
	     
	     Integer senderId = getUserDetailsDao.getSenderAndReceiverUserId(user.getMobileNo());
    	 Integer receiverId = getUserDetailsDao.getSenderAndReceiverUserId(mobileNo);
	     
	     if(getUserDetailsDao.checkUser(mobileNo)){
	    	 System.out.println(senderId+" --- "+receiverId);
	    	 
	    	 User receiver = new User(receiverId);
	    	 User moneyReceiver = getUserDetailsDao.getAllUserDetails(recUser);
	    	 
	    	 Transaction trans = new Transaction(amount,receiver);
	    	 
	    	 //Notifications notify = new Notifications(receiver);
	     	
	    	 if(senderId!=receiverId){
	    		 MakeTransactionDao mtDao = new MakeTransactionDao();
	    		 UserTransactionDetailsDao dtlDao = new UserTransactionDetailsDao();
	    		 if(mtDao.doTransaction(trans,senderId)&&dtlDao.insertNotificationDetails(trans,user,moneyReceiver)){
	    		 	msg = msg + "Transaction Successful";
	    		 	nextPage = "Home.jsp";
	    		 }else{
	    			 msg = msg + "Transaction Failed";
	    			 nextPage = "SendMoney.jsp";
	    		 }
	    	 }else{
	    		 	msg = msg + "Sorry you can't send the money to urself";
	    		 	nextPage = "SendMoney.jsp"; 
	    	 }
	    }else{
	    		msg = msg + "Transaction Failed!User doesn't exist";
	    		nextPage = "SendMoney.jsp";
	    }
	     
	     request.setAttribute("message", msg);
	     RequestDispatcher rDisp = request.getRequestDispatcher(nextPage);
	     rDisp.forward(request, response);
	}

}
