package com.org.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.org.dao.UserDetailsDao;
import com.org.dao.UserTransactionDetailsDao;
import com.org.model.User;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/logout.do")
public class LogoutServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sess = request.getSession();
		String msg = "";
		
		User user = (User)sess.getAttribute("user");
		
		UserDetailsDao userDtlDao = new UserDetailsDao();
		UserTransactionDetailsDao transactionDetailsDao = new UserTransactionDetailsDao();
		
		userDtlDao.enterLogoutTime(user);//Logout
		transactionDetailsDao.deleteNotifications(user);
		
		sess.removeAttribute("user");
		sess.invalidate();
		
		msg = msg + "Logout Successfully";
		request.setAttribute("message", msg);
		RequestDispatcher rDis = request.getRequestDispatcher("Login.jsp");
		rDis.forward(request, response);
		
	}

}
