package com.org.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.org.businessService.RegisterService;
import com.org.dao.RegisterDao;
import com.org.model.User;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register.do")
public class RegisterServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uName = request.getParameter("uName");
		String pwd = request.getParameter("pwd");
		long mobNo = Long.parseLong(request.getParameter("mobNo"));
		String emailId = request.getParameter("eml");
		
		System.out.println(uName+"---"+pwd+"-----"+mobNo+"---------"+emailId);
		
		String msg="";
		String forwardPage = "";
		
		User user = new User(uName,pwd,mobNo,emailId);
		
		RegisterService rServ = new RegisterService();
		
		if(rServ.authenticateUserDetails(user)){
		
			RegisterDao rDao = new RegisterDao();
		
			if(rDao.addUser(user)){
				msg = msg+"Registered Successfully";
				System.out.println(msg);
				forwardPage = forwardPage + "Login.jsp";
			}else{
				msg = msg+"Duplicate user";
				System.out.println(msg);
				forwardPage = forwardPage + "Register.jsp";
			}
		}else{
			msg = msg + "Invalid Password";
			System.out.println(msg);
			forwardPage = forwardPage + "Register.jsp";
		}
		System.out.println(msg);
		request.setAttribute("message", msg);
		RequestDispatcher disp = request.getRequestDispatcher(forwardPage);
		disp.forward(request, response);
	}

}
