package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.org.model.User;

public class EditUserDetailsDao {
	public boolean editUserDetails(User user,int userId){
		boolean flag = false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "update users set user_name=?, mobile_no=?, email_id=?, password=? where user_id=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setString(1, user.getUserName());
			ps.setLong(2, user.getMobileNo());
			ps.setString(3, user.getEmailId());
			ps.setString(4, user.getPassword());
			ps.setInt(5, userId);
			 
			int check = ps.executeUpdate();
			 
			if(check==1){
				flag = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return flag;
	}
}
