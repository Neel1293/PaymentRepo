package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.org.model.User;

public class UserDetailsDao {
	
	public boolean checkUser(Long mobNo){
		boolean flag = false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
		
			String query = "select * from users where mobile_no=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setLong(1, mobNo);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				flag = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}	
		
		return flag;
	}
	
	/*public int getSenderUserId(String userName){
		int senderUserId = 0;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "select user_id from users where user_name=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setString(1, userName);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				senderUserId = rs.getInt(1);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return senderUserId;
	} */
	
	public int getSenderAndReceiverUserId(Long mobileNo){
		int userId = 0;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "select user_id from users where mobile_no=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setLong(1, mobileNo);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				userId = rs.getInt(1);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return userId;
	}
	
	//Login
	public boolean enterLoginTime(User user){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "update users set login_time=NOW() where mobile_no=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setLong(1, user.getMobileNo());
			
			int check = ps.executeUpdate();
			
			if(check==1){
				flag = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return flag;
	}
	
	//Logi
		public boolean enterLogoutTime(User user){
			boolean flag = false;
			
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
				
				String query = "update users set logout_time=NOW() where mobile_no=?";
				
				PreparedStatement ps = conn.prepareStatement(query);
				
				ps.setLong(1, user.getMobileNo());
				
				int check = ps.executeUpdate();
				
				if(check==1){
					flag = true;
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return flag;
		}
	
	//For Session Object
	public User getAllUserDetails(User loginUser){
		User user = new User();
		
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "select * from users where mobile_no=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setLong(1, loginUser.getMobileNo());
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				user.setUserId(rs.getInt(1));
				user.setUserName(rs.getString(2));
				user.setMobileNo(rs.getLong(3));
				user.setEmailId(rs.getString(4));
				user.setPassword(rs.getString(5));
				user.setLoginTime(rs.getTimestamp(6));
				user.setLogoutTime(rs.getTimestamp(7));
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return user;
	}

}
