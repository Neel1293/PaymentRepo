package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.org.model.Notifications;
import com.org.model.Status;
import com.org.model.Transaction;
import com.org.model.User;

public class UserTransactionDetailsDao {
	

	public ArrayList<Transaction> getAllUserTransactionsDetails(User modelUser) {
		ArrayList<Transaction> transactionAl = new ArrayList<Transaction>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");

			String query = "select u.user_name,u.mobile_no,t.amount_sent,t.date,s.status from status s inner join transaction_Histories t inner join users u on s.status_id=t.status_id and t.receiver_id=u.user_id where t.sender_id=?";

			PreparedStatement ps = conn.prepareStatement(query);

			ps.setInt(1, modelUser.getUserId());

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Transaction t = new Transaction();

				// Using Setter
				User u = new User();
				u.setUserName(rs.getString(1));
				u.setMobileNo(rs.getLong(2));
				t.setUser(u);

				t.setAmountSent(rs.getDouble(3));
				t.setTransactionDate(rs.getTimestamp(4));

				/*
				 * Status s =new Status(); s.setStatus(rs.getString(4));
				 */
				// Using Parameterize Constructor
				Status st = new Status(rs.getString(5));
				t.setStatus(st);

				transactionAl.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return transactionAl;
	}
	
	public ArrayList<Transaction> getAllUserReceiveTransactionsDetails(User modelUser){
		ArrayList<Transaction> transactionAl = new ArrayList<Transaction>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");

			String query = "select u.user_name,u.mobile_no,t.amount_sent,t.date,s.status from status s inner join transaction_Histories t inner join users u on s.status_id=t.status_id and t.sender_id=u.user_id where t.receiver_id=?";

			PreparedStatement ps = conn.prepareStatement(query);

			ps.setInt(1, modelUser.getUserId());

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Transaction t = new Transaction();

				// Using Setter
				User u = new User();
				u.setUserName(rs.getString(1));
				u.setMobileNo(rs.getLong(2));
				t.setUser(u);

				t.setAmountSent(rs.getDouble(3));
				t.setTransactionDate(rs.getTimestamp(4));

				/*
				 * Status s =new Status(); s.setStatus(rs.getString(4));
				 */
				// Using Parameterize Constructor
				Status st = new Status(rs.getString(5));
				t.setStatus(st);

				transactionAl.add(t);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return transactionAl;
		
	}
	
	
	public boolean insertNotificationDetails(Transaction trans, User sender, User receiver){
		boolean flag = false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "insert into notifications(notification,user_id,date) values (?,?,NOW())";
			
			PreparedStatement ps = conn.prepareStatement(query);
				
			ps.setString(1, "You have received Rs."+trans.getAmountSent()+" from "+sender.getUserName()+" having no. "+ sender.getMobileNo());
			ps.setInt(2, receiver.getUserId());
					
			int check = ps.executeUpdate();
			
			if(check==1){
				flag = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return flag;
	}
	
	public ArrayList<Notifications> getAllUserNotifications(User loginUser){
		ArrayList<Notifications> alNotify = new ArrayList<Notifications>();
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "select n.notification from notifications n inner join users u on n.user_id=u.user_id where n.user_id=? and date between u.logout_time and u.login_time";
		
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setInt(1, loginUser.getUserId());
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				Notifications notifications = new Notifications();
				notifications.setNotification(rs.getString(1));
				alNotify.add(notifications);
			}
			
			System.out.println("dao"+alNotify.size());
		}catch(Exception e){
			e.printStackTrace();
		}
		return alNotify;
	}
	
	//Delete Notifications
	public void deleteNotifications(User user){
		
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "delete from notifications where user_id=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, user.getUserId());
			
			ps.executeUpdate();	
			
			String sql = "select * from notifications";
			
			PreparedStatement ps1 = conn.prepareStatement(sql);
			
			ResultSet rs = ps1.executeQuery();
			
			if(!(rs.next())){
				System.out.println("Truncating");
				String delsql = "truncate notifications";
				PreparedStatement ps2 = conn.prepareStatement(delsql);
				ps2.executeUpdate();
				System.out.println("Truncated..");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
}
