package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.org.model.User;

public class RegisterDao {
	
	public boolean addUser(User user){
		boolean flag = false;
		 try{
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			 
			 String query1 = "select * from users where mobile_no=?";
			 
			 PreparedStatement ps1 = conn.prepareStatement(query1);
			 ps1.setLong(1, user.getMobileNo());
			 
			 ResultSet rs1 = ps1.executeQuery();
			 
			 if(!(rs1.next())){
				 String query2 = "insert into users(user_name,mobile_no,email_id,password) values (?,?,?,?)";
			 
				 PreparedStatement ps = conn.prepareStatement(query2);
			 
				 ps.setString(1, user.getUserName());
				 ps.setLong(2, user.getMobileNo());
				 ps.setString(3, user.getEmailId());
				 ps.setString(4, user.getPassword());
			 
				 int check = ps.executeUpdate();
				 
				 if(check==1){
					 flag = true;
				 }
			 
			 }
			 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		
		return flag;
	}

}
