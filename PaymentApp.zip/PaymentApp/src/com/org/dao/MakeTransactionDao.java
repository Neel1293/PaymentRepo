package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import com.org.model.Transaction;

public class MakeTransactionDao {
	
	public boolean doTransaction(Transaction t, int senderId){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "insert into transaction_histories(status_id,amount_sent,sender_id,receiver_id,date) values (?,?,?,?,NOW())";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setInt(1, 1);
			ps.setDouble(2, t.getAmountSent());
			ps.setInt(3, senderId);
			ps.setInt(4, t.getUser().getUserId());
			//ps.setTimestamp(5, );
			
			int check = ps.executeUpdate();
			
			if(check==1){
				flag = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return flag;
	}

}
