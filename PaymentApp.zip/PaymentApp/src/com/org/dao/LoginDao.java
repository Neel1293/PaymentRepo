package com.org.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.org.model.User;

public class LoginDao {
	
	public boolean checkUser(User user){
		boolean flag = false;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PGI?user=root&password=neel3210");
			
			String query = "select user_id from users where mobile_no=? and password=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			
			ps.setLong(1, user.getMobileNo());
			ps.setString(2, user.getPassword());
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				flag = true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return flag;
	}

}
